#ifndef COLLGE_STUDENT_H
#define COLLGE_STUDENT_H
#include"Student.h"
#include<iostream>
#include<string>
#include<fstream>

using namespace std;



class college_student:public Student
{
    public:
        college_student(int NUMBER,string NAME,string SEX,int AGE,string GRADECLASS,string MAJOR,string ADDRESS,string PHONENUMBER)
        {
            number=NUMBER;
            name=NAME;
            sex=SEX;
            age=AGE;
            gradeclass=GRADECLASS;
            major=MAJOR;
            address=ADDRESS;
            phonenumber=PHONENUMBER;
        }
        college_student()
{
    number=0;
    name='0';
    sex="male";
    gradeclass='0';
}

        collge_student(const college_student& other);
        void college_Input(college_student *head);
        void college_Search(college_student *head);
        void college_Display(college_student *head);
        void college_Edit(college_student *head);
        void college_Statistic(college_student *head);
        void college_Delete(college_student *head);

        int getnumber(){return number;}
        string getname(){return name;}
        string getsex(){return sex;}
        int getage(){return age;}
        string getgradeclass(){return gradeclass;}
        string getmajor(){return major;}
        string getaddress(){return address;}
        string getphonenumber(){return phonenumber;}


        college_student *head;
        college_student *next;
    private:
        int number;
        string name;
        string sex;
        int age;
        string gradeclass;
        string major;
        string address;
        string phonenumber;


};



#endif // COLLGE_STUDENT_H
