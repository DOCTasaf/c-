#ifndef PRIMARY_STUDENT_H
#define PRIMARY_STUDENT_H
#include"Student.h"
#include<fstream>
#include<iostream>
#include<string>
using namespace std;


class primary_student:public Student
{
    public:
        primary_student(int NUMBER,string NAME,string SEX,int AGE,string GRADECLASS,int ENGLISH,int MATH,int CHINESE)
        {
            number=NUMBER;
            name=NAME;
            sex=SEX;
            age=AGE;
            gradeclass=GRADECLASS;
            English=ENGLISH;
            Math=MATH;
            Chinese=CHINESE;

        }
        primary_student(){}
        //virtual ~primary_student();
        high_student(const primary_student& other);
        void primary_Input(primary_student *head);
        void primary_Search(primary_student *head);
        void primary_Display(primary_student *head);
        void primary_Edit(primary_student *head);
        void primary_Statistic(primary_student *head);
        void primary_Delete(primary_student *head);

        int getnumber(){return number;}
        string getname(){return name;}
        string getsex(){return sex;}
        int getage(){return age;}
        string getgradeclass(){return gradeclass;}
        int getEnglish(){return English;}
        int getMath(){return Math;}
        int getChinese(){return Chinese;}


        primary_student *head;
        primary_student *next;
    private:
        int number;
        string name;
        string sex;
        int age;
        string gradeclass;
        int English;
        int Math;
        int Chinese;



};


#endif // COLLGE_STUDENT_H
