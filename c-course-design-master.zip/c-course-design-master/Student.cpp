#include "Student.h"

Student::Student()
{


}

Student::~Student()
{
    //dtor
}
/*
Student::Student(const Student& other)
{
    //copy ctor
}*/
