#ifndef HIGH_STUDENT_H
#define HIGH_STUDENT_H
#include"Student.h"
#include"primary_student.h"
#include<iostream>
#include<string>
#include<fstream>


using namespace std;


class high_student:public primary_student
{
    public:
        high_student(int NUMBER,string NAME,string SEX,int AGE,string GRADECLASS,int ENGLISH,int MATH,int CHINESE,int GEOGRAPHY,int HISTORY,string ADDRESS)
        {
            number=NUMBER;
            name=NAME;
            sex=SEX;
            age=AGE;
            gradeclass=GRADECLASS;
            English=ENGLISH;
            Math=MATH;
            Chinese=CHINESE;
            Geography=GEOGRAPHY;
            History=HISTORY;
            address=ADDRESS;
        }
        high_student(){}
        //virtual ~high_student();
        high_student(const high_student& other);
        void high_Input(high_student *head);
        void high_Search(high_student *head);
        void high_Display(high_student *head);
        void high_Edit(high_student *head);
        void high_Statistic(high_student *head);
        void high_Delete(high_student *head);

        int getnumber(){return number;}
        string getname(){return name;}
        string getsex(){return sex;}
        int getage(){return age;}
        string getgradeclass(){return gradeclass;}
        int getEnglish(){return English;}
        int getMath(){return Math;}
        int getChinese(){return Chinese;}
        int getGeography(){return Geography;}
        int getHistory(){return History;}
        string getaddress(){return address;}

        high_student *head;
        high_student *next;
    private:
        int number;
        string name;
        string sex;
        int age;
        string gradeclass;
        int English;
        int Math;
        int Chinese;
        int Geography;
        int History;
        string address;



};

#endif // HIGH_STUDENT_H
