#include<iostream>
#include<iomanip>
#include<string>
#include<stdlib.h>
#include"collge_student.h"
#include"primary_student.h"
#include"high_student.h"

#define Password "stu123"
#define Account "xuan"
using namespace std;


int main()
{
    system("color F0");

    string PASSWORD;
    string ACCOUNT;
    cout<<"-----                                                            -----"<<endl;
    cout<<"|                      / ��ӭʹ��ѧ������ϵͳ \\                      |"<<endl;
    cout<<"==================----------------------------------=================="<<endl<<endl;
    cout<<"����Ա�û���:";
    cin>>ACCOUNT;
    cout<<"����Ա����:";
    cin>>PASSWORD;

    if(PASSWORD!=Password||ACCOUNT!=Account)
    {
        cout<<"����Ա�û�������������޷���Ȩ�ޣ�"<<endl;
        return 0;
    }

    primary_student pst;
    high_student hst;
    college_student cst;

    cout<<"-----                                                            -----"<<endl;
    cout<<"|                         / ѧ������ϵͳ \\                           |"<<endl;
    cout<<"                                                       �û�:"<<Account<<"�ѵ�¼"<<endl;
    cout<<"                                                              ��ӭʹ��"<<endl;
    cout<<"======================================================================"<<endl<<endl;
    cout<<endl;
    cout<<"                        ��ѡ��Ҫ������ѧ������                        "<<endl<<endl;
    cout<<"                              1 Сѧ��                                "<<endl<<endl;
    cout<<"                              2 ��ѧ��                                "<<endl<<endl;
    cout<<"                              3 ��ѧ��                                "<<endl<<endl;
    cout<<"������Ҫ������ѧ�����ͣ�";
    int CHOICE;
    cin>>CHOICE;

switch(CHOICE)
{
case 1:
    {


    while(1)
    {
    cout<<"                          ��ѡ��Ҫ���еĲ���                          "<<endl;
    cout<<"                           1 ����ѧ����Ϣ                             "<<endl;
    cout<<"                           2 ����ѧ����Ϣ                             "<<endl;
    cout<<"                           3 ��ʾѧ����Ϣ                             "<<endl;
    cout<<"                           4 �༭ѧ����Ϣ                             "<<endl;
    cout<<"                           5 ɾ��ѧ����Ϣ                             "<<endl;
    cout<<"                           6 ͳ��ѧ����Ϣ                             "<<endl;
    //cout<<"                           7 ����ѧ����Ϣ                             "<<endl;
    //cout<<"                           8 ��ȡѧ����Ϣ                             "<<endl;
    cout<<"                           0 �˳���Ϣϵͳ                             "<<endl;
    cout<<"======================================================================"<<endl;
    cout<<"                     ��ϵͳ���Զ���ȡ����ѧ����Ϣ                     "<<endl<<endl<<endl;
    cout<<"������Ҫ���еĲ�����";

    int choice;
    cin>>choice;
    switch(choice)
    {
    case 0:
        return 0;
    case 1:
        {
            pst.primary_Input(pst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 2:
        {
            pst.primary_Search(pst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 3:
        {
            pst.primary_Display(pst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 4:
        {
            pst.primary_Edit(pst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 5:
        {
            pst.primary_Delete(pst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 6:
        {
            pst.primary_Statistic(pst.head);
            cout<<"======================================================================"<<endl;
        }break;
    default :
        cout<<"��Ч����"<<endl;break;
    }
    }
    }break;

case 2:
    {
    while(1)
    {

    cout<<"                          ��ѡ��Ҫ���еĲ���                          "<<endl;
    cout<<"                           1 ����ѧ����Ϣ                             "<<endl;
    cout<<"                           2 ����ѧ����Ϣ                             "<<endl;
    cout<<"                           3 ��ʾѧ����Ϣ                             "<<endl;
    cout<<"                           4 �༭ѧ����Ϣ                             "<<endl;
    cout<<"                           5 ɾ��ѧ����Ϣ                             "<<endl;
    cout<<"                           6 ͳ��ѧ����Ϣ                             "<<endl;
    //cout<<"                           7 ����ѧ����Ϣ                             "<<endl;
    //cout<<"                           8 ��ȡѧ����Ϣ                             "<<endl;
    cout<<"                           0 �˳���Ϣϵͳ                             "<<endl;
    cout<<"======================================================================"<<endl;
    cout<<"                     ��ϵͳ���Զ���ȡ����ѧ����Ϣ                     "<<endl<<endl<<endl;
    cout<<"������Ҫ���еĲ�����";


    int choice;
    cin>>choice;
    switch(choice)
    {
    case 0:
        return 0;
    case 1:
        {
            hst.high_Input(hst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 2:
        {
            hst.high_Search(hst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 3:
        {
            hst.high_Display(hst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 4:
        {
            hst.high_Edit(hst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 5:
        {
            hst.high_Delete(hst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 6:
        {
            hst.high_Statistic(hst.head);
            cout<<"======================================================================"<<endl;
        }break;

    default :
        cout<<"��Ч����"<<endl;break;
    }
    }
    }break;

    case 3:
    {

    while(1)
    {
    cout<<"                          ��ѡ��Ҫ���еĲ���                          "<<endl;
    cout<<"                           1 ����ѧ����Ϣ                             "<<endl;
    cout<<"                           2 ����ѧ����Ϣ                             "<<endl;
    cout<<"                           3 ��ʾѧ����Ϣ                             "<<endl;
    cout<<"                           4 �༭ѧ����Ϣ                             "<<endl;
    cout<<"                           5 ɾ��ѧ����Ϣ                             "<<endl;
    cout<<"                           6 ͳ��ѧ����Ϣ                             "<<endl;
    cout<<"                           0 �˳���Ϣϵͳ                             "<<endl;
    cout<<"======================================================================"<<endl;
    cout<<"                     ��ϵͳ���Զ���ȡ����ѧ����Ϣ                     "<<endl<<endl<<endl;
    cout<<"������Ҫ���еĲ�����";


    int choice;
    cin>>choice;
    switch(choice)
    {
    case 0:
        return 0;
    case 1:
        {
            cst.college_Input(cst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 2:
        {
            cst.college_Search(cst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 3:
        {
            cst.college_Display(cst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 4:
        {
            cst.college_Edit(cst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 5:
        {
            cst.college_Delete(cst.head);
            cout<<"======================================================================"<<endl;
        }break;
    case 6:
        {
            cst.college_Statistic(cst.head);
            cout<<"======================================================================"<<endl;
        }break;
    default :
        cout<<"��Ч����"<<endl;break;

    }
    }
    }break;

    default :
        cout<<"��Ч����"<<endl;break;
}


return 0;
}
