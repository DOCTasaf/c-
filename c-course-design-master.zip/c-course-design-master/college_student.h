#ifndef COLLEGE_STUDENT_H_INCLUDED
#define COLLEGE_STUDENT_H_INCLUDED



#endif // COLLGE_STUDENT_H_INCLUDED

#include<iostream>
#include<string>

class college_student
{
    private:
    int number;
    string name;
    string sex;
    int age;
    string gradeclass;
    string major;
    string address;
    double phonenumber;
    double size;
    college_student *Cst;

    public:
    void Input();
    void Search();
    void Display();
    void Edit();
    void Delete();
    void Static();
    void Save();
    void Read();
    ~college_student();

};

